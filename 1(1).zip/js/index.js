    //update
var bob_h5 = "https://www.mlqqch.com/entry/register?agent_code=5885149";//bob-h5
var bob_pc = "https://www.on4xgo.com/register/?agent_code=5885149";//bob-pc
var boyu_pc = "https://www.boyu1012.com:30111/register/?i_code=4431125";//boyu-pc
var boyu_h5 = "https://www.boyuvip161.com:30112/entry/register/?i_code=4431125";//boyu-h5
var app_pc = "http://www.ag6oc.com/?agent_code=5885149";//app_pc
var app_h5 = "http://www.ag6oc.com/?agent_code=5885149";//app_h5
